# huge-grid
A jQuery plugin that allows displaying table with huge amounts of data while having a small performance hit.

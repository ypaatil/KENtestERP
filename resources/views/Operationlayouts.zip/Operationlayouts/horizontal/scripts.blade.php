		<!-- Back to top -->
		<a href="#top" id="back-to-top"><span class="feather feather-chevrons-up"></span></a>

		<!-- Jquery js-->
		<script src="{{URL::asset('assets/plugins/jquery/jquery.min.js')}}"></script>

		<!--Moment js-->
		<script src="{{URL::asset('assets/plugins/moment/moment.js')}}"></script>

		<!-- Bootstrap4 js-->
		<script src="{{URL::asset('assets/plugins/bootstrap/popper.min.js')}}"></script>
		<script src="{{URL::asset('assets/plugins/bootstrap/js/bootstrap.min.js')}}"></script>

		<!--Othercharts js-->
		<script src="{{URL::asset('assets/plugins/othercharts/jquery.sparkline.min.js')}}"></script>

		<!-- Circle-progress js-->
		<script src="{{URL::asset('assets/plugins/circle-progress/circle-progress.min.js')}}"></script>

		<!--Horizontalmenu js -->
		<script src="{{URL::asset('assets/plugins/horizontal-menu/horizontal-menu.js')}}"></script>

		<!--Sticky js -->
		<script src="{{URL::asset('assets/plugins/sticky/sticky.js')}}"></script>

		<!-- P-scroll js-->
		<script src="{{URL::asset('assets/plugins/p-scrollbar/p-scrollbar.js')}}"></script>

		<!--Sidebar js-->
		<script src="{{URL::asset('assets/plugins/sidebar/sidebar.js')}}"></script>

		<!-- Select2 js -->
		<script src="{{URL::asset('assets/plugins/select2/select2.full.min.js')}}"></script>

        @yield('scripts')

        <!-- Custom js-->
		<script src="{{URL::asset('assets/js/custom.js')}}"></script>

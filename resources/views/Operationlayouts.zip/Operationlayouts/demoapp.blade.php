     @include('layouts.masters.vertical.demomaster');
{{-- @include('layouts.masters.horizontal.commonmaster'); --}}
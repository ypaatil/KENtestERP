     @include('layouts.masters.vertical.clientmaster');
{{-- @include('layouts.masters.horizontal.commonmaster'); --}}

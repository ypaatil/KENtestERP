     @include('layouts.masters.vertical.jobmaster');
{{-- @include('layouts.masters.horizontal.commonmaster'); --}}

     @include('layouts.masters.vertical.empmaster');
{{-- @include('layouts.masters.horizontal.commonmaster'); --}}

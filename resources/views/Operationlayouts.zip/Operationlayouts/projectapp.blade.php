     @include('layouts.masters.vertical.projectmaster');
{{-- @include('layouts.masters.horizontal.commonmaster'); --}}

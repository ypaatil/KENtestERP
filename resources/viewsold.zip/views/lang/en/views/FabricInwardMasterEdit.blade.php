@extends('layouts.master') 

@section('content')
<div class="row">
<div class="col-12">
<div class="page-title-box d-sm-flex align-items-center justify-content-between">
<h4 class="mb-sm-0 font-size-18">Fabric Inward</h4>

<div class="page-title-right">
<ol class="breadcrumb m-0">
<li class="breadcrumb-item"><a href="javascript: void(0);">Transaction</a></li>
<li class="breadcrumb-item active">Fabric Inward</li>
</ol>
</div>

</div>
</div>
</div>
<!-- end page title -->

<div class="row">
<div class="col-xl-12">
<div class="card">
<div class="card-body">
<h4 class="card-title mb-4">Fabric Inward</h4>
@if ($errors->any())

<div class="col-md-6">
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    </div>
@endif
 
 
@if(isset($FabricInwardMasterList)) 
<form action="{{ route('FabricInward.update',base64_encode($FabricInwardMasterList->in_code)) }}" method="POST" enctype="multipart/form-data">
@method('put')
@csrf 
<div class="row">
<div class="col-md-2">
    <div class="mb-3">
        <label for="in_date" class="form-label">In Date</label>
        <input type="date" name="in_date" class="form-control" id="in_date" value="{{ $FabricInwardMasterList->in_date }}" required>
        
       @foreach($counter_number as  $row)
      <input type="hidden" name="PBarcode" class="form-control" id="PBarcode" value="{{ $row->PBarcode }}">
      <input type="hidden" name="CBarcode" class="form-control" id="CBarcode" value="{{ $row->CBarcode }}">
@endforeach 
        <input type="hidden" name="in_code" class="form-control" id="in_code" value="{{ base64_encode($FabricInwardMasterList->in_code) }}">
<input type="hidden" name="c_code" class="form-control" id="c_code" value="{{ $FabricInwardMasterList->c_code }}">
<input type="hidden" name="created_at" class="form-control" id="created_at" value="{{ $FabricInwardMasterList->created_at }}">  
<input type="hidden" name="userId" value="{{ Session::get('userId') }}" class="form-control" id="formrow-email-input">

    </div>
</div>
  


 <div class="col-md-2">
<div class="mb-3">
<label for="formrow-inputState" class="form-label">PO Code</label>   
<select name="po_code" class="form-select" id="po_code" onchange="getPODetails();"   >
<option value="">PO code</option>
@foreach($POList as  $rowpol)
{
    <option value="{{ $rowpol->pur_code  }}"
     {{ $rowpol->pur_code == $FabricInwardMasterList->po_code ? 'selected="selected"' : '' }} 
    >{{ $rowpol->pur_code }}</option>
}
@endforeach
</select>
</div>
</div>

<div class="col-md-2">
<div class="mb-3">
<label for="formrow-invoice_no-input" class="form-label">Invoice No</label>
<input type="text" name="invoice_no" id="invoice_no" class="form-control" value="{{ $FabricInwardMasterList->invoice_no }}" id="formrow-invoice_no-input" required>
</div>
</div>

<div class="col-md-2">
<div class="mb-3">
<label for="formrow-invoice_date-input" class="form-label">Invoice Date</label>
<input type="date" name="invoice_date" id="invoice_date" class="form-control" id="formrow-invoice_date-input" value="{{ $FabricInwardMasterList->invoice_date }}">
</div>
</div>




<div class="col-md-2">
<div class="mb-3">
<label for="formrow-inputState" class="form-label">PO</label>
<select name="po_type_id" class="form-select" id="po_type_id" onchange="getPartyDetails();">
<option value="">Type</option>
@foreach($POTypeList as  $rowpo)
{
    <option value="{{ $rowpo->po_type_id  }}"
    
     {{ $rowpo->po_type_id == $FabricInwardMasterList->po_type_id ? 'selected="selected"' : '' }}      
    
    >{{ $rowpo->po_type_name }}</option>
}
@endforeach
</select>
</div>
</div>
 
</div>
<div class="row">

<div class="col-md-3">
<div class="mb-3">
<label for="formrow-inputState" class="form-label">Supplier</label>
<select name="Ac_code" class="form-select" id="Ac_code" required>
<option value="">--Select Buyer--</option>
@foreach($Ledger as  $row)
{
    <option value="{{ $row->ac_code }}"
    {{ $row->ac_code == $FabricInwardMasterList->Ac_code ? 'selected="selected"' : '' }}   >  
    {{ $row->ac_name }}</option>
}
@endforeach
</select>
</div>
</div> 

 <div class="col-md-2">
<div class="mb-3">
<label for="formrow-inputState" class="form-label">CP Type</label>
<select name="cp_id" class="form-select" id="cp_id" required onchange="serBarocode();" disabled>
<option value="">--Select CP Type--</option>
@foreach($CPList as  $rowCP)
{
    <option value="{{ $rowCP->cp_id }}"
    
  {{ $rowCP->cp_id == $FabricInwardMasterList->cp_id ? 'selected="selected"' : '' }}       
    
    >{{ $rowCP->cp_name }}</option>
}
@endforeach
</select>
</div>
</div>




  <div class="col-md-2">
  <div class="form-check form-check-primary mb-3">
<input class="form-check-input" type="checkbox" id="is_opening" name="is_opening"
   @if($FabricInwardMasterList->is_opening==1)checked @endif>
<label class="form-check-label" for="is_opening">
    Opening Stock
</label>
</div>
 
</div>


  
</div>

<input type="number" value="{{ count($FabricInwardDetails) }}" name="cntrr" id="cntrr" readonly="" hidden="true"  />
<div class="table-wrap">
<div class="table-responsive">
<table id="footable_2" class="table  table-bordered table-striped m-b-0  footable_2">
<thead>
<tr>

<th>SrNo</th>
<th>Item Name</th>
<th>Part</th>
<th>Meter</th>
<th>Gram/Meter</th>
<th>KG</th>
<th>Rate Per Meter</th>
<th>Amount</th>
<th>TrackCode</th>
<th>Print</th>
 
<th>Add/Remove</th>
</tr>
</thead>
<tbody>

@if(count($FabricInwardDetails)>0)

@php $no=1; @endphp
@foreach($FabricInwardDetails as $List) 
 
<tr>
<td><input type="text" name="id[]" value="@php echo $no; @endphp" id="id" style="width:50px;"/></td>
<td> <select name="item_code[]"  id="item_code" style="width:200px; height:30px;" required>
<option value="">--Item--</option>
@foreach($ItemList as  $row)
{
    <option value="{{ $row->item_code }}"
    {{ $row->item_code == $List->item_code ? 'selected="selected"' : '' }}       
    >{{ $row->item_name }}</option>
}
@endforeach
</select></td>  
<td> <select name="part_id[]"  id="part_id" style="width:200px; height:30px;" required>
<option value="">--Part--</option>
@foreach($PartList as  $row)
{
    <option value="{{ $row->part_id }}"
    {{ $row->part_id == $List->part_id ? 'selected="selected"' : '' }}       
    >{{ $row->part_name }}</option>
}
@endforeach
</select></td>
  
<td><input type="hidden" class="TAGAQTY" onkeyup="mycalc();" value="{{ $List->taga_qty }}" id="taga_qty1" style="width:50px;"/><input type="number" step="0.01"class="METER" name="meter[]" onkeyup="mycalc();" value="{{ $List->meter }}" id="meter1" style="width:80px; height:30px;" required/></td>
<td><input type="number" step="0.01"  name="gram_per_meter[]"  value="{{ $List->gram_per_meter }}" id="gram_per_meter" style="width:80px; height:30px;" required/></td>
<td><input type="number" step="0.01" class="KG" name="kg[]" onkeyup="mycalc();" value="{{ $List->kg }}" id="kg" style="width:80px; height:30px;" required/></td>
<td><input type="number" step="any"    name="item_rates[]"   value="{{ $List->item_rate }}" id="item_rates" style="width:80px;height:30px;" required/>
<td><input type="number" step="any" class="AMT" readOnly  name="amounts[]"   value="{{ $List->amount }}" id="amounts" style="width:80px;height:30px;" required/>
<td><input type="text" name="track_code[]"  value="{{ $List->track_code }}" id="track_code" style="width:80px; height:30px;" required readOnly/></td>
<td><i   style="font-size:25px;" onclick="CalculateRowPrint(this);" name="print"  class="fa fa-print" ></td>
 
<td><input type="button" style="width:40px;" onclick="insertcone();" name="print" value="+" class="btn btn-warning pull-left"> <input type="button" class="btn btn-danger pull-left" onclick="deleteRowcone(this);" value="X" ></td>
</tr>
@php $no=$no+1;  @endphp
 
@endforeach

@else

<tr>
<td><input type="text" name="id[]" value="1" id="id" style="width:50px;"/></td>
<td> <select name="item_code[]" class="item"  id="item_code" style="width:100px;" required>
<option value="">--Item--</option>
@foreach($ItemList as  $row)
{
    <option value="{{ $row->item_code }}">{{ $row->item_name }}</option>
}
@endforeach
</select></td>   
 


<td> <select name="part_id[]" class="part"   id="part_id" style="width:100px;" required>
<option value="">--Part--</option>
@foreach($PartList as  $row)
{
    <option value="{{ $row->part_id }}">{{ $row->part_name }}</option>
}
@endforeach
</select></td>
 
<td><input type="hidden" class="TAGAQTY" onkeyup="mycalc();" value="1" id="taga_qty1" style="width:50px;"/><input type="number" step="0.01" class="METER" name="meter[]" onkeyup="mycalc();" value="0" id="meter1" style="width:80px;" required/></td>
<td><input type="number" step="0.01"  name="gram_per_meter[]"  value="0" id="gram_per_meter" style="width:80px;" required/></td>
<td><input type="number" step="0.01" class="KG" name="kg[]" onkeyup="mycalc();" value="0" id="kg" style="width:80px;" required/></td>
<td><input type="number" step="any"    name="item_rates[]"   value="0" id="item_rates" style="width:80px;height:30px;" required/>
<td><input type="number" step="any" class="AMT" readOnly  name="amounts[]"   value="0" id="amounts" style="width:80px;height:30px;" required/>
<td><input type="text" name="track_code[]"  value="" id="track_code" style="width:80px;" /></td>
<td><i   style="font-size:25px;" onclick="CalculateRowPrint(this);" name="print"  class="fa fa-print" ></td>
 
<td><input type="button" style="width:40px;" onclick="insertcone();" name="print" value="+" class="btn btn-warning pull-left"> <input type="button" class="btn btn-danger pull-left" onclick="deleteRowcone(this);" value="X" ></td>
</tr>
@endif
 </tbody>
<tfoot>
<tr>
<th>Roll No</th>
<th>Item Name</th>
<th>Part</th>
<th>Meter</th>
<th>Gram/Meter</th>
<th>KG</th>
<th>Rate Per Meter</th>
<th>Amount</th>
<th>TrackCode</th>
<th>Print</th>
 
<th>Add/Remove</th>
</tr>
</tfoot>
</table>
</div>
</div>
 
</div>

<div class="row">
  <div class="col-md-2">
    <div class="mb-3">
        <label for="total_meter" class="form-label">Total Meter</label>
        <input type="number" step="0.01"  name="total_meter" class="form-control" id="total_meter" value="{{ $FabricInwardMasterList->total_meter }}" required>
    </div>
</div>

 <div class="col-md-2">
    <div class="mb-3">
        <label for="total_kg" class="form-label">Total KG</label>
        <input type="number" step="0.01"  name="total_kg" class="form-control" id="total_kg" value="{{ $FabricInwardMasterList->total_kg }}">
    </div>
</div>


<div class="col-md-2">
    <div class="mb-3">
        <label for="total_qty" class="form-label">Total Taga</label>
        <input type="number"   name="total_taga_qty" class="form-control" id="total_taga_qty" value="{{ $FabricInwardMasterList->total_taga_qty }}" required>
    </div>
</div>
 
 <div class="col-md-2">
<div class="mb-3">
<label for="formrow-email-input" class="form-label">Total Amount</label>
<input type="text" name="total_amount" class="form-control" id="total_amount" value="{{ $FabricInwardMasterList->total_amount }}" required>
</div>
</div>

    <div class="col-sm-8">
        <div class="mb-3">
            <label for="formrow-inputState" class="form-label">Narration</label>
            <input type="text" name="in_narration" class="form-control" id="in_narration"   value="{{ $FabricInwardMasterList->in_narration }}" />
        </div>
    </div>


<div class="col-sm-6">
<label for="formrow-inputState" class="form-label"></label>
<div class="form-group">
<button type="submit" class="btn btn-primary w-md"    onclick="UpdateBarcode();EnableFields();">Submit</button>
<a href="{{ Route('FabricInward.index') }}" class="btn btn-warning w-md">Cancel</a>
</div>
</div>

 
</div>
</form>
@endif


</div>
<!-- end card body -->
</div>
<!-- end card -->
</div>
<!-- end col -->


<!-- end col -->
</div>
<!-- end row -->

 <script src="{{ URL::asset('assets/libs/jquery/jquery.min.js')}}"></script>
<!-- end row -->
<script>

$(document).on("click", 'input[name^="print[]"]', function (event) {
    
        CalculateRowPrint($(this).closest("tr"));
        
    });
	 	
function CalculateRowPrint(btn)
	{ 
	    var row = $(btn).closest("tr");
       	var width=+row.find('input[name^="width[]"]').val();
        var meter=+row.find('input[name^="meter[]"]').val();
         var kg=+row.find('input[name^="kg[]"]').val();
        var color_id=+row.find('select[name^="color_id[]"]').val();
        var part_id=+row.find('select[name^="part_id[]"]').val();
        var quality_code=+row.find('select[name^="quality_code[]"]').val();
        var track_code=row.find('input[name^="track_code[]"]').val();
        var style_no=$("#style_no").val();
        var job_code=$("#job_code").val();
        
      //  alert(track_code);
        $.ajax({
            type: "GET",
            dataType:"json",
            url: "{{ route('PrintBarcode') }}",
            data:{'width':width,'meter':meter,'color_id':color_id,'quality_code':quality_code,'kg':kg,  'part_id':part_id,'track_code':track_code,'style_no':style_no,'job_code':job_code},
            success: function(data){
                 
            if((data['result'])=='success')
            {
              alert('Print Barcode For Roll: '+track_code);
            }
            else
            {
                $alert('Data Can Not Be Printed');
            }
            
        }
        });
        
}

function EnableFields()
{
     $("select").prop('disabled', false);
}



function getJobCardDetails()
{
   
    var job_card_no=$("#job_code").val();
     
    $.ajax({
            type: "GET",
            dataType:"json",
            url: "{{ route('JobCardDetail') }}",
            data:{'job_card_no':job_card_no},
            success: function(data){
            $("#cp_id").val(data[0]['cp_id']);
            $("#style_no").val(data[0]['style_no']);
            $("#Ac_code").val(data[0]['Ac_code']);
            $("#fg_id").val(data[0]['fg_id']);
                
                
            //  if(data[0]['cp_id']==1)
            // {
                     
            //         ++PBarcode;
            //         $("#track_code").val('P'.concat(PBarcode.toString()));
            //       alert($("#track_code").val());
            // }
            // else
            // {       var CBar='';
            //         CBar='I' + parseInt(++CBarcode);
            //         $("#track_code").val(CBar);
            // }   
                   
                
        }
        });
}


  function getPODetails()
{
   
    var po_code=$("#po_code").val();
    
    $.ajax({
            type: "GET",
            dataType:"json",
            url: "{{ route('PODetail') }}",
            data:{'po_code':po_code},
            success: function(data){
                
                $("#po_type_id").val(data[0]['po_type_id']);
                $("#Ac_code").val(data[0]['Ac_code']);
               
        }
        });
        
        
       
 
}

 var PBarcode=$("#PBarcode").val();
var CBarcode=$("#CBarcode").val();


function UpdateBarcode()
{
     $("#PBarcode").val(PBarcode);
      $("#CBarcode").val(CBarcode);
}

function serBarocode()
{
            if($("#cp_id").val()==1)
            {
                     
                    ++PBarcode;
                    $("#track_code").val('P'.concat(PBarcode.toString()));
                   //alert($("#track_code").val());
            }
            else if($("#cp_id").val()==2)
            {       var CBar='';
                    CBar='I' + parseInt(++CBarcode);
                     $("#track_code").val(CBar);
            }
}


$("table.footable_2").on("keyup", 'input[name^="gram_per_meter[]"],input[name^="meter[]"]', function (event) {
        CalculateRow($(this).closest("tr"));
        
    });
	 	
	function CalculateRow(row)
	{ 
		var gram_per_meter=+row.find('input[name^="gram_per_meter[]"]').val();
        var meter=+row.find('input[name^="meter[]"]').val();
	 	var kg=parseFloat(meter * gram_per_meter).toFixed(2);
        row.find('input[name^="kg[]"]').val(kg);
		mycalc();
}


function getDetails(po_code){

$.ajax({
type:"GET",
url:"{{ route('getPoMasterDetail') }}",
//dataType:"json",
data:{po_code:po_code},
success:function(response){
console.log(response);

$("#Ac_code").val(response[0].Ac_code);
$("#invoice_no").val(response[0].supplierRef);
$("#invoice_date").val(response[0].pur_date);
$("#po_type_id").val(response[0].po_type_id);
$("#in_narration").val(response[0].narration);

 gettable(po_code);


document.getElementById('Ac_code').disabled =true;
document.getElementById('po_type_id').disabled=true;


}
});
} 


var indexcone = {{ count($FabricInwardDetails) }};
//var indexcone = 2;
function insertcone(){

var table=document.getElementById("footable_2").getElementsByTagName('tbody')[0];
var row=table.insertRow(table.rows.length);

var cell1=row.insertCell(0);
var t1=document.createElement("input");
t1.style="display: table-cell; width:50px;";
//t1.className="form-control col-sm-1";

t1.id = "id"+indexcone;
t1.name= "id[]";
t1.value=indexcone;

cell1.appendChild(t1);
  

var cell5 = row.insertCell(1);
var t5=document.createElement("select");
var x = $("#item_code"),
y = x.clone();
y.attr("id","item_code");
y.attr("name","item_code[]");
y.width(200);
y.height(30);
y.appendTo(cell5);



var cell3 = row.insertCell(2);
var t3=document.createElement("select");
var x = $("#part_id"),
y = x.clone();
y.attr("id","part_id");
y.attr("name","part_id[]");
y.width(200);
y.height(30);
y.appendTo(cell3);

 
var t7=document.createElement("input");
t7.style="display: table-cell; width:80px;height:30px;";
t7.type="hidden";
t7.className="TAGAQTY";
t7.required="true";
t7.id = "taga_qty"+indexcone;
t7.name="taga_qty[]";
t7.onkeyup=mycalc();
t7.value="1";
cell3.appendChild(t7);

var cell7 = row.insertCell(3);
var t8=document.createElement("input");
t8.style="display: table-cell; width:80px;height:30px;";
t8.type="text";
t8.className="METER";
t8.id = "meter"+indexcone;
t8.name="meter[]";
t8.onkeyup=mycalc();
cell7.appendChild(t8);

var cell7 = row.insertCell(4);
var t8=document.createElement("input");
t8.style="display: table-cell; width:80px;height:30px;";
t8.type="text";
t8.id = "gram_per_meter"+indexcone;
t8.name="gram_per_meter[]";
t8.onkeyup=mycalc();
cell7.appendChild(t8);

var cell7 = row.insertCell(5);
var t8=document.createElement("input");
t8.style="display: table-cell; width:80px;height:30px;";
t8.type="text";
t8.className="KG";
t8.id = "kg"+indexcone;
t8.name="kg[]";
t8.onkeyup=mycalc();
cell7.appendChild(t8);


var cell3 = row.insertCell(6);
var t3=document.createElement("input");
t3.style="display: table-cell; width:80px;height:30px;";
t3.type="number";
t3.step="any";
t3.required="true";
t3.id = "item_rates"+indexcone;
t3.name="item_rates[]";
t3.value="0";
cell3.appendChild(t3);

var cell3 = row.insertCell(7);
var t3=document.createElement("input");
t3.style="display: table-cell; width:80px;height:30px;";
t3.type="number";
t3.readOnly="true";
t3.step="any";
t3.required="true";
t3.className="AMT";
t3.id = "amounts"+indexcone;
t3.name="amounts[]";
t3.value="0";
cell3.appendChild(t3);


var cell7 = row.insertCell(8);
var t7=document.createElement("input");
t7.style="display: table-cell; width:80px;height:30px;";
t7.type="text";
t7.id = "track_code"+indexcone;
t7.name="track_code[]";
if($("#cp_id").val()==1)
{
   t7.value='P'+(++PBarcode);
}
else
{
    t7.value='I'+(++CBarcode);
}
cell7.appendChild(t7);



var cell7 = row.insertCell(9);
cell7.innerHTML='<i class="fa fa-print" name="print" style="font-size:25px;" onclick="CalculateRowPrint(this);"></i>';

 
var cell8=row.insertCell(10);
var btnAdd = document.createElement("INPUT");
btnAdd.id = "Abutton";
btnAdd.type = "button";
btnAdd.name = "print";
btnAdd.className="btn btn-warning pull-left";
btnAdd.value = "+";
btnAdd.setAttribute("onclick", "insertcone();CalculateRowPrint(this);");
cell8.appendChild(btnAdd);


var btnRemove = document.createElement("INPUT");
btnRemove.id = "Dbutton";
btnRemove.type = "button";
btnRemove.className="btn btn-danger pull-left";
btnRemove.value = "X";
btnRemove.setAttribute("onclick", "deleteRowcone(this)");
cell8.appendChild(btnRemove);

var w = $(window);
var row = $('#footable_3').find('tr').eq(indexcone);

if (row.length){
$('html,body').animate({scrollTop: row.offset().top - (w.height()/2)}, 1000 );
}

document.getElementById('cntrr').value = parseInt(document.getElementById('cntrr').value)+1;

indexcone++;
mycalc();
recalcIdcone();
}


  $(document).on("keyup", 'input[name^="meter[]"],input[name^="item_rates[]"]', function (event) {
        CalculateRow($(this).closest("tr"));
       });
    function CalculateRow(row)
    {
        var item_qtys=+row.find('input[name^="meter[]"]').val();
        var item_rates=+row.find('input[name^="item_rates[]"]').val();
        var amount=(parseFloat(item_qtys)*parseFloat(item_rates)).toFixed();
        row.find('input[name^="amounts[]"]').val(amount);
        mycalc();
    }
 

function mycalc()
{  
document.getElementById("total_taga_qty").value =document.getElementById('cntrr').value;

sum1 = 0.0;
var amounts = document.getElementsByClassName('METER');
//alert("value="+amounts[0].value);
for(var i=0; i<amounts .length; i++)
{ 
var a = +amounts[i].value;
sum1 += parseFloat(a);
}
document.getElementById("total_meter").value = sum1.toFixed(2);


sum1 = 0.0;
var amounts = document.getElementsByClassName('KG');
//alert("value="+amounts[0].value);
for(var i=0; i<amounts .length; i++)
{ 
var a = +amounts[i].value;
sum1 += parseFloat(a);
}
document.getElementById("total_kg").value = sum1.toFixed(2);

 
 sum1 = 0.0;
var amounts = document.getElementsByClassName('AMT');
//alert("value="+amounts[0].value);
for(var i=0; i<amounts .length; i++)
{ 
var a = +amounts[i].value;
sum1 += parseFloat(a);
}
document.getElementById("total_amount").value = sum1.toFixed(2);
 
 
}



function deleteRowcone(btn) {
if(document.getElementById('cntrr').value > 1){
var row = btn.parentNode.parentNode;
row.parentNode.removeChild(row);

document.getElementById('cntrr').value = document.getElementById('cntrr').value-1;

recalcIdcone();
mycalc();
if($("#cntrr").val()<=0)
{		
document.getElementById('Submit').disabled=true;
}
 
}
}



function recalcIdcone(){
$.each($("#footable_2 tr"),function (i,el){
$(this).find("td:first input").val(i); // Simply couse the first "prototype" is not counted in the list
})
}
 
</script>

<!-- end row -->
@endsection
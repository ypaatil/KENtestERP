      
   @extends('layouts.master') 

@section('content')   
<meta name="csrf-token" content="{{ csrf_token() }}">
<div class="row">
<div class="col-12">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0 font-size-18">Vendor Purchase Order Model</h4>

        <div class="page-title-right">
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="javascript: void(0);">Transaction</a></li>
                <li class="breadcrumb-item active">Vendor Process Order </li>
            </ol>
        </div>

    </div>
</div>
</div>


<!--<div class="row">-->
<!--    <div class="col-md-3">-->
<!--    <div class="card mini-stats-wid" style="background-color:#152d9f;" >-->
<!--    <div class="card-body">-->
<!--    <div class="d-flex">-->
<!--    <div class="flex-grow-1">-->
<!--    <p class="  fw-medium" style="color:#fff;">No. of Orders</p>-->
    <!--<h4 class="mb-0" style="color:#fff;">  </h4>-->
<!--    </div>-->

<!--    <div class="flex-shrink-0 align-self-center">-->
<!--    <div class="  avatar-sm rounded-circle bg-primary" style="background-color:#152d9f;">-->
<!--    <span class="avatar-title" style="background-color:#152d9f;">-->
<!--    <i class="bx bx-copy-alt font-size-24"></i>-->
<!--    </span>-->
<!--    </div>-->
<!--    </div>-->
<!--    </div>-->
<!--    </div>-->
<!--    </div>-->
<!--    </div>-->
<!--    <div class="col-md-3">-->
<!--    <div class="card mini-stats-wid" style="background-color:#556ee6;">-->
<!--    <div class="card-body">-->
<!--    <div class="d-flex">-->
<!--    <div class="flex-grow-1">-->
<!--    <p class="  fw-medium" style="color:#fff;" >Order Qty</p>-->
    <!--<h4 class="mb-0" style="color:#fff;" >  </h4>-->
<!--    </div>-->
<!--    <div class="flex-shrink-0 align-self-center ">-->
<!--    <div class="avatar-sm rounded-circle bg-primary  ">-->
<!--    <span class="avatar-title  " style="background-color:#556ee6;" >-->
<!--   <i class="bx bx-purchase-tag-alt font-size-24"></i>-->
<!--    </span>-->
<!--    </div>-->
<!--    </div>-->
<!--    </div>-->
<!--    </div>-->
<!--    </div>-->
<!--    </div>-->
    
<!--    <div class="col-md-3">-->
<!--    <div class="card mini-stats-wid" style="background-color:#f79733;">-->
<!--    <div class="card-body">-->
<!--    <div class="d-flex">-->
<!--    <div class="flex-grow-1">-->
<!--    <p class="  fw-medium" style="color:#fff;">Order Value</p>-->
    <!--<h4 class="mb-0" style="color:#fff;">  </h4>-->
<!--    </div>-->
<!--   <div class="flex-shrink-0 align-self-center">-->
<!--    <div class="avatar-sm rounded-circle bg-primary  " >-->
<!--    <span class="avatar-title  " style="background-color:#f79733;">-->
<!--    <i class="bx bx-archive-in font-size-24"></i>-->
<!--    </span>-->
<!--    </div>-->
<!--    </div>-->
<!--    </div>-->
<!--    </div>-->
<!--    </div>-->
<!--    </div>-->
<!--    </div>  -->
                          @if($chekform->write_access==1)    
                        <div class="row">
                        <div class="col-md-12">
                        <a href="{{ Route('VendorPurchaseOrder.create') }}"><button type="button" class="btn btn-primary w-md">Add New Record</button></a>
                        
                        </div>
                        </div>
                        @endif
                        
                         
                        @if(session()->has('message'))
                        <div class="col-md-6">
                            <div class="alert alert-success">
                                {{ session()->get('message') }}
                            </div>
                        </div>
                        @endif

                        @if(session()->has('messagedelete'))
                        <div class="col-md-6">
                            <div class="alert alert-danger">
                                {{ session()->get('messagedelete') }}
                            </div>
                        </div>
                        @endif
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
        
                                    <table data-order='[[ 0, "desc" ]]' data-page-length='25' id="datatable-buttons" class="table table-bordered dt-responsive nowrap w-100">
                                          <thead>
                                            <tr>
                                                <th>SrNo</th>
                                                <th>Process PO No</th>
                                                <th>Status</th>
                                                 <th>Process Type</th>
                                                  <th>Vendor Name</th>
                                                <th>Sales Order No</th>
                                                <th>PO Date</th>
                                                <th>Delivery Date</th>
                                                <th>Buyer Name</th>
                                                <th>Buyer Po No</th>  
                                                <th>Main Style</th>
                                                  <th>Process Order Qty</th>
                                                <th>Print</th>
                                                <th>Edit</th>  
                                                <th>Order</th>
                                                <th>Delete</th>
                                            </tr>
                                            </thead>
        
                                            <tbody>
 
                                            @foreach($VendorPurchaseOrderList as $row)    
                                            <tr>
                                                <td > {{ substr($row->vpo_code,4,15)  }} </td>
                                                  
                                                <td > {{ $row->vpo_code }} </td> 
                                                <td style="text-align:center;"> {{ $row->job_status_name  }} </td>
                                                <td> {{ $row->process_name  }} </td>
                                                <td> {{ $row->vendorName  }} </td>
                                                <td> {{ $row->sales_order_no  }} </td>
                                                <td nowrap> {{ $row->vpo_date  }} </td>
                                                <td nowrap> {{ $row->delivery_date  }} </td>
                                                <td> {{ $row->Ac_name  }} </td>
                                                <td> {{ $row->po_code  }} </td>
                                                <td> {{ $row->mainstyle_name  }} </td>
                                                <td> {{ $row->final_bom_qty  }} </td>
                                                <td>
                                                    <a target="_blank" class="btn btn-outline-secondary btn-sm print" href="VPPrint/{{ $row->vpo_code }}" title="print">
                                                        <i class="fas fa-print"></i>
                                                    </a>
                                                </td>
                                                @if($chekform->edit_access==1)
                                                <td>
                                                    <a class="btn btn-outline-secondary btn-sm edit" href="{{route('VendorPurchaseOrder.edit', $row->vpo_code)}}" title="Edit">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </a>
                                                </td>
                                                @else
                                                <td>
                                                    <a class="btn btn-outline-secondary btn-sm edit" href="" title="Edit">
                                                        <i class="fas fa-lock"></i>
                                                    </a>
                                                </td>
                                                @endif
                                                <td>
                                                    <a class="btn btn-outline-warning btn-sm" href="javascript:void(0);" vpo_code="{{$row->vpo_code}}" onclick="closeOrder(this);" title="close_order">
                                                        <i class="fas fa-home"></i>
                                                    </a>
                                                </td>
                                                @if($chekform->delete_access==1) 
                                                <td>
                                                
                                        <button  class="btn   btn-sm delete"  data-placement="top" id="DeleteRecord" data-token="{{ csrf_token() }}" data-id="{{ $row->vpo_code }}"  data-route="{{route('VendorPurchaseOrder.destroy', $row->vpo_code )}}" title="Delete">
                                        <i class="fas fa-trash"></i>
                                        </button>   
                                                
                                                </td>
                                                
  @else

                         <td>
                               
<button class="btn btn-outline-secondary btn-sm delete" data-toggle="tooltip" data-placement="top" title="Delete">
<i class="fas fa-lock"></i>
</button>
                                </td>

@endif
                                            </tr>
                                            @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div> <!-- end row -->
                        
<script src="{{ URL::asset('assets/libs/jquery/jquery.min.js')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript"> 
 function closeOrder(row)
   {
       $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });   
        var vpo_code = $(row).attr('vpo_code');
        Swal.fire({
          title: 'Are you sure?',
          text: "This order will close",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, do it!'
        }).then((result) => {
          if (result.isConfirmed) 
          {
               $.ajax({
               type: "POST", 
               url: "{{ route('PurchaseOrderClose') }}",
               data:{'vpo_code':vpo_code},
               success: function(data)
               {
                   Swal.fire(
                      'Closed!',
                      'Your Order has been closed.',
                      'success'
                    )
                }
                }); 
          }
        })
   }
 $(document).on('click','#DeleteRecord',function(e) {

    var Route = $(this).attr("data-route");
    var id = $(this).data("id");
    var token = $(this).data("token");

   //alert(Route);
  
  //alert(data);
    if (confirm("Are you sure you want to Delete this Record?") == true) {
  $.ajax({
         url: Route,
         type: "DELETE",
          data: {
          "id": id,
          "_method": 'DELETE',
           "_token": token,
           },
         
         success: function(data){

         //  console.log(data);
         location.reload();

         }
});
}

 });
</script>  
                        
                        @endsection
<!DOCTYPE html>
<html lang="en">
   <head>
      @php setlocale(LC_MONETARY, 'en_IN'); @endphp
      <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Ken Enterprises Pvt. Ltd.</title>
      <meta name="author" content="">
      <!-- Web Fonts
         ======================= -->
      <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900' type='text/css'>
      <!-- Stylesheet
         ======================= -->
      <link rel="stylesheet" type="text/css" href="{{ URL::asset('InvoiceAssets/bootstrap.min.css') }}"/>
      <link rel="stylesheet" type="text/css" href="{{ URL::asset('InvoiceAssets/all.min.css') }}"/>
      <link rel="stylesheet" type="text/css" href="{{ URL::asset('InvoiceAssets/style.css') }}"/>
      <style>
         .table-bordered td, .table-bordered th {
         border: 1px solid #0c0c0c;
         body{
         font-family: "Times New Roman", Times, serif;
         }
         }
      </style>
   </head>
   <body>
      <!-- Container -->
      <div class="container-fluid invoice-container">
          <a  href="javascript:window.print()" class="button_niks btn  btn-info btn-rounded "> Print</a>
          <button type="button" id="export_button" class="btn btn-warning">Export</button>
         <!-- Header -->
         <div class="invoice" id="invoice">
            <!-- Main Content -->
            <main>
               <!-- Item Details -->
               <div class="row">
                  <div class="col-md-4">
                     <p><img src="http://kenerp.com/logo/ken.jpeg"  alt="Ken Enterprise Pvt. Ltd." height="130" width="230"> </p>
                  </div>
                  <div class="col-md-6">
                     <h4 class="mb-0" style="font-weight:bold;">KEN GLOBAL DESIGNS PRIVATE LIMITED</h4>
                     <h6 class="mb-0"><b>Address:</b> {{$FirmDetail->Address}}</h6>
                     <h6 class="mb-0" style="margin-left:40px;"><b>GST No:</b> {{$FirmDetail->gst_no}} <b>PAN No:</b> {{$FirmDetail->pan_no}}</h6>
                  </div>
                  <div class="col-md-2">    
                  </div>
               </div>
               <hr>
               <div class="">
                  <h4 class="text-4">
                  <h4 class="text-center mt-2" style="color: #000;font-size:20px;font-weight:bold;">Fabric Inward and Outward Stock Report   {{ date('d-m-Y',strtotime($fdate)) }} and {{ date('d-m-Y',strtotime($tdate)) }}				</h4>
               </div>
               <style>
                  .table{
                  display: table;
                  width:100%;
                  border-collapse:collapse;
                  }
                  .tr {
                  display: table-row;
                  padding: 2px;
                  }
                  .tr p {
                  margin: 0px !important; 
                  }
                  .td {
                  display: table-cell;
                  padding: 8px;
                  width: 410px;
                  border: #000000 solid 1px;
                  }
                  @page{
                  margin: 5px !important;
                  }
                  .merged{
                  width:25%;
                  height:25%;
                  padding: 8px;
                  display: table-cell;
                  background-image: url('http://kenerp.org/logo/ken.jpeg');background-repeat: no-repeat;background-size:cover;
                  }
               </style>
               <!-- Passenger Details -->
               <div class="">
                  <table class="table table-bordered text-1 table-sm" style="height:10vh; ">
                     <thead style="text-align:center;">
                        <tr>
                           <th rowspan="2">Date</th>
                           <th rowspan="2">Opening Stock</th>
                           <th rowspan="2">Inward</th>
                           <th rowspan="2">Outward</th>
                           <th rowspan="2">Closing Stock</th>
                        </tr>
                     </thead>
                     <tbody>
                        @php 
                        $totalInward=0; $totalOutward=0; $no=0;
                        foreach ($period as $dt) 
                        {
                        $FabInOutStockList=DB::select("select 
                        ((select ifnull(sum(meter),0) as meter from inward_details where in_date < '".$dt."') -
                        (select ifnull(sum(meter),0) as meter from fabric_outward_details where fout_date < '".$dt."')) as OpeningStock,
                        (select ifnull(sum(meter),0) as meter from inward_details where in_date = '".$dt."') as Inward,
                        (select ifnull(sum(meter),0) as meter from fabric_outward_details where fout_date = '".$dt."') as Outward,
                        ((select ifnull(sum(meter),0) as meter from inward_details where in_date = '".$dt."') -
                        (select ifnull(sum(meter),0) as meter from fabric_outward_details where fout_date = '".$dt."')) as ClosingStock");
                        @endphp
                        <tr>
                           <td style="text-align:center;">{{   date('d-m-Y',strtotime($dt)) }}  </td>
                           <td style="text-align:right;">{{ money_format('%!i',round($FabInOutStockList[0]->OpeningStock,2)) }}</td>
                           <td style="text-align:right;">{{ money_format('%!i',round($FabInOutStockList[0]->Inward,2)) }}</td>
                           <td style="text-align:right;">{{ money_format('%!i',round($FabInOutStockList[0]->Outward,2)) }}</td>
                           <td style="text-align:right;">{{ money_format('%!i',round(($FabInOutStockList[0]->OpeningStock + $FabInOutStockList[0]->Inward - $FabInOutStockList[0]->Outward),2))  }}</td>
                        </tr>
                        @php
                        $totalInward=$totalInward + $FabInOutStockList[0]->Inward;
                        $totalOutward=$totalOutward + $FabInOutStockList[0]->Outward;
                        $no=$no+1;     
                        }
                        @endphp
                     <tfoot>
                        <tr>
                           <td>   </td>
                           <td style="font-weight:bold;">  <b>Total :   </b></td>
                           <td style="font-weight:bold;text-align:right;"> <b> {{ money_format('%!i',round($totalInward,2)) }}  </b></td>
                           <td style="font-weight:bold;text-align:right;">{{money_format('%!i',round($totalOutward,2))}}</td>
                           <td>   </td>
                        </tr>
                        <tr>
                           <td>   </td>
                           <td style="font-weight:bold;">  <b>Average :   </b></td>
                           <td style="font-weight:bold;text-align:right;"> <b> {{ money_format('%!i',round(($totalInward/$no),2)) }}  </b></td>
                           <td style="font-weight:bold;text-align:right;">{{money_format('%!i',round(($totalOutward/$no),2))}}</td>
                           <td>   </td>
                        </tr>
                     </tfoot>
                     </tbody>
                     </tbody>
                  </table>
               </div>
            </main>
         </div>
      </div>
      <p class="text-center d-print-none"><a href="/SalesOrderCosting">&laquo; Back to List</a></p>
   </body>
   <script src="{{ URL::asset('http://kenerp.org/assets/libs/jquery/jquery.min.js')}}"></script>
   <script src="https://cdn.ckeditor.com/4.15.0/standard/ckeditor.js"></script>
   <script type="text/javascript" src="{{URL::asset('assets/js/exporttoexcel.js')}}"></script>
   <script>  
        
     function html_table_to_excel(type)
     {
        var data = document.getElementById('invoice');

        var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

        XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

        XLSX.writeFile(file, 'Fabric Inward and Outward Stock Report.' + type);
      }

      const export_button = document.getElementById('export_button');
    
      export_button.addEventListener('click', () =>  {
            html_table_to_excel('xlsx');
      });
      
      $('#printInvoice').click(function()
      {
          Popup($('.invoice')[0].outerHTML);
          function Popup(data) 
          {
              window.print();
              return true;
          }
      });
      
      
   </script>
</html>